
 <?php 
$wasError=false;

echo $wasError;
session_start();
 if ((!isset($_SESSION))||($_SESSION["login"] !="yes") )
 {
    header('Location: http://codersforcauses.com/SciBowlStats/login.php');
 }
$tablename = $_SESSION["username"]."SETTINGS";
  $db = new PDO("mysql:dbname=codersfo_scibowlstats;host=localhost","codersfo_lahera1","PaulaLahera" ); 
                   
                      $rows = $db->query("SELECT * FROM $tablename");  
?>  

<?php
if($_POST['addthing'] == "Submit") 
    {

      $errorMessage="";
        $key=$_POST["key"];
    $name=$_POST["name"];
    $wasError=false;
    if(empty($name)) {
      $errorMessage= $errorMessage. "\n You forgot to name the item to add.\n <br>"; 
        $wasError = TRUE;
    }
    if(empty($key)) {
      $errorMessage= $errorMessage. "\n You forgot to specify what you wanted to add.\n <br>"; 
        $wasError = TRUE;
    }
    if($wasError==false)
    {
      $conn = mysqli_connect("localhost", "codersfo_lahera1", "PaulaLahera", "codersfo_scibowlstats");
       if (!$conn) {
               die("Connection failed: Try again later. " . mysqli_connect_error());
          }
          if ($key=="sub")
          {
            $thename = $_SESSION["username"].$name;
         $sql = "CREATE TABLE $thename (`player` TEXT, `answer` TEXT, `interrupt` TEXT);";

            if (mysqli_query($conn, $sql)) {
             } 
           
         else {
             echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
        $sql = "INSERT INTO `codersfo_scibowlstats`.`$tablename` (`key`, `name`) VALUES ('sub', '$name');";

            if (mysqli_query($conn, $sql)) {
       } 
           
         else {
             echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
      }
      if ($key=="player")
          {
         $sql = "INSERT INTO `codersfo_scibowlstats`.`$tablename` (`key`, `name`) VALUES ('player', '$name');";

            if (mysqli_query($conn, $sql)) {
       } 
           
         else {
             echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
      }
    }

    }


?>

<?php
if($_POST['dropthing'] == "Submit") 
    {
 
      
      $errorMessage="";
        $todrop=$_POST["thingtodrop"];
        
        $db2 = new PDO("mysql:dbname=codersfo_scibowlstats;host=localhost","codersfo_lahera1","PaulaLahera" ); 
                   
        $rows = $db2->query("SELECT * FROM $tablename");  
 
        foreach ($rows as $row){
          if ($row['name']==$todrop)
          {
            $key = $row['key'];
            $name = $todrop;
        
          }
        
        }
    
      $conn = mysqli_connect("localhost", "codersfo_lahera1", "PaulaLahera", "codersfo_scibowlstats");
       if (!$conn) {
               die("Connection failed: Try again later. " . mysqli_connect_error());
          }
          if ($key=="sub")
          {
            $thename = $_SESSION["username"].$name;
         $sql = "DROP TABLE $thename;";

            if (mysqli_query($conn, $sql)) {
             } 
           
         else {
             echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
        $sql = "DELETE FROM `$tablename` WHERE name='$name';";

            if (mysqli_query($conn, $sql)) {
       } 
           
         else {
             echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
      }
      if ($key=="player")
          {
          $sql = "DELETE FROM `$tablename` WHERE name='$name';";

            if (mysqli_query($conn, $sql)) {
       } 
           
         else {
             echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
      }
      mysql_close($db2);
    }


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Catmint
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130910

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SciBowl Stats</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script type="text/javascript" src="jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="jquery.slidertron-1.3.js"></script>
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<h1><a href="#">SciBowl Stats</a></h1>
		</div>
		<div id="menu">
			<ul>
				<li class="/"><a href="index.html" title="">Homepage</a></li>
				<li><a href="login.php" title="">Log In</a></li>
				<li><a href="faq.html" title="">FAQ</a></li>
				<li><a href="contact.php"  title="">Contact</a></li>
			</ul>
		</div>
	</div>
</div>

<div id="wrapper">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Your Stuff!</h2>
				</div>
		
<?php if ($wasError ==true)
{
  echo $errorMessage;
}
?>
<table align="center">
<tr>

<td>

                         <h4>Add player or subject</h4>

                         <form method="post" action="userpage.php" >   
                         To Add:   <select name="key">
                                    <option value="sub">subject</option>
                                     <option value="player">player</option> 
                                     </select><br>
                           Name: <input type="text" name="name" maxlength="100" value="" />
                   
                                          <br>

                                 <input type="submit" name="addthing" value="Submit" />
                                                 </form> 
                                                 </td>

                                                 <td></td><td>

                         

                         


                         <h4>Drop a player or subject</h4>
                         Warning: You will irreversibly lose <br> all data from the subject or player <br>you drop.
                         <br><br>
                         <form method="post" action="userpage.php" >   
                         To Drop:   <select name="thingtodrop">
                         <?php 
                         $rows = $db->query("SELECT * FROM $tablename");  
                         foreach ($rows as $row){ 
                          $thing = $row[name];
                          ?>  <option value="<?php echo $thing ?>"><?php echo $thing ?></option>  <?php
                         }
                         ?>
                            
                                  
                                     </select><br>
                           

                                 <input type="submit" name="dropthing" value="Submit" />
                                                 </form> 
                                                 </td>

                                            </tr>


                                                 </table>

                                                 <table align="center">
<tr>
<td></td>
<td> </td> <td> </td><td></td><td style="min-width:150px;"> </td><td style="min-width:150px;"> </td>
</tr>
<tr>

<td>
        <h4>Your Subjects </h4>
                            <ul>
                    <?php 
                       $db = new PDO("mysql:dbname=codersfo_scibowlstats;host=localhost","codersfo_lahera1","PaulaLahera" ); 
                   
                      $rows = $db->query("SELECT * FROM $tablename");  
    
                           if(!empty($rows)){ foreach ($rows as $row){
                             ?> 

                       <?php 

                       if ($row['key']=="sub")
                       {
                        ?> <li> <?php 
                        $word = $row["name"]; 
                        $word = strtolower($word);
                        $word = ucfirst($word);
                        echo $word;
                       ?> </li> <?php
                       } ?>
                       


                        <?php
                    }
                  }
                             //mysql_close($db); // */
                          
                       
                        ?> </ul>  

                        </td> <td></td> <td>
                  
                        <h4> Your SciBowl Players
                         </h4>
                       
                         <ul>
                         <?php

                         if(!empty($rows)){ $rows = $db->query("SELECT * FROM $tablename");  
                         foreach ($rows as $row){ 
                         if ($row['key']=="player")
                       {
                        ?> <li> <?php 
                        echo $row["name"];
                       ?> </li> <?php
                       } ?>
                        
                         
                         <?php } } 
                        
                         ?>
                         </ul>
                        
                         </td>

                       <td style=""></td >


                         <td colspan="2" style="">
                         <h4>Generate Graph</h4>
                         <form method="post" action="graph.php" >   
                          Graph Subjects:  
             
                          <input type="checkbox" id = "all" name="subject[]" value="all"><label for = "all">All Subjects</label>
                         <?php $rows = $db->query("SELECT * FROM  $tablename"); 
                         $count = 0; 
                         foreach ($rows as $row){ 
                         if ($row['key']=="sub")
                       {
                        $count++;
                        $thing = $row["name"];
                        ?> 
                         <input type="checkbox" id ="<?php echo $thing ?>" name="subject[]" value="<?php echo $thing ?>"><label for = "<?php echo $thing ?>"><?php echo $thing ?> </label>
                       
                         <?php
                         if ($count >2)
                         {
                          $count = 0;
                          ?> <br><?php
                         }
                       } ?>
                        
                         
                         <?php }
                        
                         ?>
                        
                     <br>
                           Players:  
                        
                          <input type="checkbox" id = "allsub" name="players[]" value="all"><label for = "allsub">All Players</label>
                         <?php $rows = $db->query("SELECT * FROM $tablename"); 
                         $count=0; 
                         foreach ($rows as $row){ 
                         if ($row['key']=="player")
                       {
                        $thing = $row["name"];
                        $count++;
                        ?> 
                         <input type="checkbox" id ="<?php echo $thing ?>" name="players[]" value="<?php echo $thing ?>"><label for = "<?php echo $thing ?>"><?php echo $thing ?> </label>
                       
                         <?php
                         if ($count >2)
                         {
                          $count = 0;
                          ?> <br>
                           <?php
                         }
                       } ?>
                        
                         
                         <?php }
                        
                         ?>
                        
                                  
                                    <br>
                           
<br>
                                 <input type="submit" name="makegraph" value="Submit" />
                                                 </form> </td>

                         </tr>

                         
                         </table>

                                                 <a href="game.php" class="button">Start Game!</a>
<br><br><br><br> <br><br><br>
              <form style = "display:inline!important; width:40px;overflow: hidden; height=auto" method="post" action="logout.php" >
                  <input type="submit" name="Log out" value="Log out" />
        </form>

		</div>
	</div>

</div>

<div id="copyright" class="container">
	<p>Copyright (c) 2015 scibowlstats.com. All rights reserved. | Design by <a href="http://www.freecsstemplates.org/" rel="nofollow">FreeCSSTemplates.org</a>.</p>
</div>
</body>
<?php mysql_close($db);?>
</html>
