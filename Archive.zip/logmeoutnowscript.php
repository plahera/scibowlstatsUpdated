<?php session_start();
$_SESSION['loggedin'] = "no";
session_destroy(); 
echo "logged out";
?>