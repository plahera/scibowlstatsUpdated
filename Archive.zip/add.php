<?php
if($_POST['addthing'] == "Submit") 
    {
        $key=$_POST["key"];
    $name=$_POST["name"];
    if(empty($name)) {
      $errorMessage= $errorMessage. "\n You forgot to name the item to add.\n <br>"; 
        $show = TRUE;
    }
    }


?>