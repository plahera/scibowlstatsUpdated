<?php 

session_start();
 if ((isset($_SESSION))&&($_SESSION["login"] =="yes") )
 {
    header('Location: http://codersforcauses.com/scibowlstats/userpage.php');
 }
    
?>

<?php
    if($_POST['formSubmit'] == "Submit") 
    {
$email = $_POST['email'];
    $username    = $_POST['username'];
        $password = $_POST['password'];
        $password2 = $_POST['password2'];
    $errorMessage = "";
    $show =FALSE;
    
         if(empty($username)) {
      $errorMessage= $errorMessage. "\n You forgot to pick your uesrname.\n <br>"; 
        $show = TRUE;
    }
         if(empty($password)) {
      $errorMessage= $errorMessage. "\n You forgot to enter a password.\n <br>"; 
        $show = TRUE;
    }
         if(empty($password2)) {
      $errorMessage= $errorMessage. "\n You forgot to confirm your password.\n <br>"; 
        $show = TRUE;
    }
        if(empty($email)) {
      $errorMessage= $errorMessage. "\n You forgot to enter your email.\n <br>";
            $show = TRUE;

    }

       
        if (strpos($email,'@') == FALSE) {
    $errorMessage= $errorMessage. "Please enter a valid email. <br>";
            $show = TRUE;
        }
        
         if ($password != $password2) {
    $errorMessage= $errorMessage. "Your passwords do not match. Please try again. <br>";
            $show = TRUE;
        }
        
        if ($show ==FALSE)
        {
            $db4 = new PDO("mysql:dbname=codersfo_scibowlstats;host=localhost","codersfo_lahera1","PaulaLahera" ); 
            $rows = $db4->query("SELECT * FROM users");     
            foreach ($rows as $row){

                 if (($row["username"]==$username))
                 {
                    $show=TRUE;
                     $errorMessage= $errorMessage. "This username is already taken. Please choose another.<br>";
                     
                 }
                if (($row["email"]==$email))
                 {
                    $show=TRUE;
                     $errorMessage= $errorMessage. "This email already has an account. <br>";
                     break;
                 }
            }
                   
        mysql_close($db4);
        }
    }
        ?>

<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Catmint
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130910

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SciBowl Stats</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script type="text/javascript" src="jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="jquery.slidertron-1.3.js"></script>
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<h1><a href="#">SciBowl Stats</a></h1>
		</div>
		<div id="menu">
			<ul>
				<li class="/"><a href="index.html" title="">Homepage</a></li>
				<li><a href="login.php" title="">Log In</a></li>
				<li><a href="faq.html" title="">FAQ</a></li>
				<li><a href="contact.php"  title="">Contact</a></li>
			</ul>
		</div>
	</div>
</div>

<div id="wrapper">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Welcome!</h2>
				</div>
			<p> <?php
        
        if ($show==TRUE)
        {
            echo $errorMessage;
            
            ?>
                        Please try again: <br>
                                                <form method="post" action="makeaccount.php" >
            Username:  <input type="text" name="username" maxlength="100" value="" />
            <br>
            Password:  <input type="password" name="password" maxlength="100" value="" />
            <br>
            Confirm your Password:  <input type="password" name="password2" maxlength="100" value="" />
           <br>
           E-mail: <input type="text" name="email" maxlength="100" value="" />
           <br>
  
           <input type="submit" name="formSubmit" value="Submit" />
        </form>
            <?php
        }
       if ($show==FALSE)
       {
           $autoResponseSubject = "scibowlstats account";
           $autoResponseMessage = "Hello,          
           Thank you for making an account here! 
           
           Here is your user information:
           Username: $username
            Password: $password
          
           Thank you.";
          mail($email, $autoResponseSubject, $autoResponseMessage);
           
        $conn = mysqli_connect("localhost", "codersfo_lahera1", "PaulaLahera", "codersfo_scibowlstats");
       if (!$conn) {
               die("Connection failed: Try again later. " . mysqli_connect_error());
          }
           

            $sql = "INSERT INTO users (username, password, email)
            VALUES ('$username', '$password','$email')";

            if (mysqli_query($conn, $sql)) {
               echo "Your account has been successfully created.";
                 $_SESSION['login'] = "yes";
             $_SESSION['username'] = $username;
             $_SESSION['password'] = $password;
               // header('Location: PAGE');
        } 
           
         else {
              echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

        $tablename = $username . "SETTINGS";
        $sql = "CREATE TABLE $tablename (`key` TEXT, `name` TEXT);";

            if (mysqli_query($conn, $sql)) {
       } 
           
         else {
             echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
           
           
        
       }
?> 

</p>
		</div>
	</div>

</div>

<div id="copyright" class="container">
	<p>Copyright (c) 2015 scibowlstats.com. All rights reserved. | Design by <a href="http://www.freecsstemplates.org/" rel="nofollow">FreeCSSTemplates.org</a>.</p>
</div>
</body>
<?php mysqli_close($conn); ?>
</html>
